# --- CONFIGURACIÓN ---
$letras1 = Read-Host "Ingresa los priemros tres caracteres del proyecto (ej. ARB)"
$letras2 = Read-Host "Ingresa los priemros tres caracteres de la especialidad (ej. ARQ)"
$textoLibre = Read-Host "Ingresa la unidad estructural completa"
$rutaCarpeta = Read-Host "Ingresa la ruta completa de la carpeta"
# ---------------------

# Construir el prefijo (Ej: ABC-DEF-MisCaracteres-)
$prefijo = "$letras1-$letras2-$textoLibre-"

# Obtener los archivos de la carpeta (excluyendo subcarpetas y directorios)
Get-ChildItem -Path $rutaCarpeta -File | ForEach-Object {
    # Combinar el prefijo con el nombre original del archivo
    $nuevoNombre = $prefijo + $_.Name
    
    # Renombrar el archivo
    Rename-Item -Path $_.FullName -NewName $nuevoNombre
    
    # Mostrar el resultado en la consola
    Write-Host "Renombrado: $($_.Name) -> $nuevoNombre" -ForegroundColor Green
}

# Línea nueva para congelar la pantalla:
Read-Host "`nProceso terminado. Presiona Enter para salir"